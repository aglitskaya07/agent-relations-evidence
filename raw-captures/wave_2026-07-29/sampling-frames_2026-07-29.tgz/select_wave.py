#!/usr/bin/env python3
"""Детерминированный отбор выборки основной волны MCP Steering Index.
Правила зафиксированы здесь кодом; результат — wave_frame.jsonl (кандидаты с рамками) и wave_selection.jsonl.
"""
import json, pathlib, re
from urllib.parse import urlparse

F = pathlib.Path(__file__).parent / "frames"
OUT = pathlib.Path(__file__).parent

PILOT_EXCLUDE = {  # уже измерены 29.07 в пилоте
    "firecrawl-mcp", "exa-mcp-server", "@upstash/context7-mcp", "@playwright/mcp",
    "chrome-devtools-mcp", "@modelcontextprotocol/server-filesystem",
}
# известные не-серверы из npm-топа (SDK/адаптеры/инфраструктура/UI)
NPM_NOT_SERVER = {
    "@hono/mcp", "mcp-proxy", "@mcp-ui/client", "@mcp-ui/server", "mcp-handler",
    "@langchain/mcp-adapters", "@supabase/mcp-utils", "@mcp-use/inspector",
    "@ai-sdk/mcp", "@modelcontextprotocol/ext-apps", "add-mcp", "mcp-remote",
    "@modelcontextprotocol/sdk", "@modelcontextprotocol/inspector", "mcp-use",
    "fastmcp", "mcp-framework", "@wong2/mcp-cli", "mcp-client", "@mcpc/core",
    "mcp-evals", "@mastra/mcp", "litemcp", "mcp-testing-kit", "@mokei/mcp",
    # добавлено после глазного прохода 29.07 (не-серверы: middleware/SDK/туннели/прокси/инструментация)
    "@ag-ui/mcp-apps-middleware", "@ag-ui/mcp-middleware", "@anthropic-ai/mcpb",
    "@clerk/mcp-tools", "@expo/mcp-tunnel", "@rekog/mcp-nest",
    "@traceloop/instrumentation-mcp", "@vercel/mcp-adapter", "supergateway",
    "hlims-mcp", "@salesforce/mcp-provider-dx-core",
    "mcp-hello-world",  # демо-фикстура, не вендорский сервер
    "n8n-nodes-mcp",    # клиентские ноды n8n, не сервер
    "pi-mcp-adapter", "workers-mcp",  # адаптер/транспорт
}
# вендор-дедуп: одно продуктовое семейство = один юнит (unified-пакет), суб-серверы/провайдеры не считаем
VENDOR_FAMILY_DROP = re.compile(r"^@transcend-io/mcp-server-|/mcp-provider-|-(linux|win32|darwin)-(x64|arm64)$")

cands = {}  # canonical_key -> record

def add(key, frame, **kw):
    r = cands.setdefault(key, {"key": key, "frames": [], "npm": None, "hosted_url": None,
                               "name": None, "desc": None, "popularity": {}})
    if frame not in r["frames"]:
        r["frames"].append(frame)
    for k, v in kw.items():
        if k == "popularity":
            r["popularity"].update(v)
        elif v and not r.get(k):
            r[k] = v

# --- 1. npm топ по скачиваниям ---
npm = json.load(open(F / "npm_top.json"))["objects"]
npm_rows = []
for o in npm:
    p = o["package"]
    dl = (o.get("downloads") or {}).get("monthly") or 0
    npm_rows.append((p["name"], dl, p.get("description") or ""))
npm_rows.sort(key=lambda x: -x[1])
taken = 0
for name, dl, desc in npm_rows:
    if taken >= 40: break
    if name in NPM_NOT_SERVER or name in PILOT_EXCLUDE: continue
    if VENDOR_FAMILY_DROP.match(name): continue
    add(name, "npm-top", npm=name, name=name, desc=desc, popularity={"npm_monthly": dl})
    taken += 1

# --- 2. PulseMCP: топ-25 npm по скачиваниям + топ-15 hosted по звёздам ---
pulse = []
for i in range(1, 6):
    pulse += json.load(open(F / f"pulse_p{i}.json")).get("servers", [])
pn = [s for s in pulse if s.get("package_registry") == "npm" and s.get("package_name")]
pn.sort(key=lambda s: -(s.get("package_download_count") or 0))
for s in pn[:25]:
    if s["package_name"] in PILOT_EXCLUDE or s["package_name"] in NPM_NOT_SERVER: continue
    add(s["package_name"], "pulsemcp", npm=s["package_name"], name=s.get("name"),
        desc=s.get("short_description"), popularity={"pulse_dl": s.get("package_download_count"), "stars": s.get("github_stars")})
ph = [s for s in pulse if s.get("remotes") and (s.get("github_stars") or 0) >= 50]
ph.sort(key=lambda s: -(s.get("github_stars") or 0))
htaken = 0
seen_domains = set()
for s in ph:
    if htaken >= 15: break
    urls = [r.get("url_direct") or r.get("url") for r in s["remotes"] if isinstance(r, dict)]
    urls = [u for u in urls if u and u.startswith("https://")]
    if not urls: continue
    host = urlparse(urls[0]).netloc
    domain = ".".join(host.split(".")[-2:])
    if not host or domain in seen_domains: continue
    seen_domains.add(domain)
    key = s.get("package_name") or host
    if key in PILOT_EXCLUDE: continue
    add(key, "pulsemcp-hosted", hosted_url=urls[0], name=s.get("name"),
        desc=s.get("short_description"), npm=s.get("package_name"),
        popularity={"stars": s.get("github_stars")})
    htaken += 1

# --- 3. Официальный реестр: серверы с remotes, сорт по имени, топ-30 ---
reg = []
for i in range(1, 9):
    reg += json.load(open(F / f"registry_p{i}.json")).get("servers", [])
reg_hosted = []
for e in reg:
    srv = e.get("server") or {}
    rems = srv.get("remotes") or []
    urls = [r.get("url") for r in rems if r.get("url", "").startswith("https://")]
    if urls:
        reg_hosted.append((srv.get("name", ""), urls[0], srv.get("description", "")))
reg_hosted.sort(key=lambda x: x[0])
seen_hosts = set()
rtaken = 0
for name, url, desc in reg_hosted:
    if rtaken >= 30: break
    host = urlparse(url).netloc
    if host in seen_hosts: continue
    seen_hosts.add(host)
    add(name, "official-registry", hosted_url=url, name=name, desc=desc)
    rtaken += 1

# --- 4. Smithery: топ-20 по useCount — только оверлап-рамка (hosted keyless=401) ---
smy = []
for i in range(1, 4):
    smy += json.load(open(F / f"smithery_p{i}.json")).get("servers", [])
smy.sort(key=lambda s: -(s.get("useCount") or 0))
smithery_top = [s["qualifiedName"] for s in smy[:20]]
for s in smy[:20]:
    qn = s["qualifiedName"].lower()
    for key, r in cands.items():
        base = (r.get("npm") or key).lower()
        if qn.split("/")[-1] in base or base.split("/")[-1] in qn:
            if "smithery-top20" not in r["frames"]:
                r["frames"].append("smithery-top20")

# --- 5. Docker: только оверлап-рамка ---
docker_names = set(json.load(open(F / "docker_names.json")))
for key, r in cands.items():
    short = (r.get("npm") or key).split("/")[-1].replace("@", "")
    for dn in docker_names:
        if dn == short or dn == short.replace("-mcp", "") or dn == short.replace("mcp-", ""):
            if "docker-catalog" not in r["frames"]:
                r["frames"].append("docker-catalog")
            break

# --- 6. Каталог claude.ai (сессионные коннекторы; Apify/Firecrawl уже в пилоте) ---
CLAUDE_AI = ["Figma", "Gmail", "Google_Calendar", "Google_Drive", "Granola",
             "Fireflies", "Notion", "Netlify", "Zoom_for_Claude"]
for c in CLAUDE_AI:
    add(f"claude-ai:{c}", "claude-ai-catalog", name=c,
        desc="коннектор claude.ai; захват: сессионный системный промпт + схемы инструментов")

sel = list(cands.values())
sel.sort(key=lambda r: (r["frames"][0], r["key"]))
with open(OUT / "wave_selection.jsonl", "w") as f:
    for r in sel:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

npm_units = [r for r in sel if r.get("npm") and not r["key"].startswith("claude-ai:")]
hosted_units = [r for r in sel if r.get("hosted_url")]
print(f"итого юнитов: {len(sel)} | c npm-каналом: {len(npm_units)} | с hosted-каналом: {len(hosted_units)} | claude.ai: {len(CLAUDE_AI)}")
from collections import Counter
print("по первичной рамке:", Counter(r["frames"][0] for r in sel))
print("\n--- npm-топ отобранные (глазами!) ---")
for r in sel:
    if r["frames"][0] == "npm-top":
        print(f"  {r['key']:45s} {r['popularity'].get('npm_monthly',0):>10,} | {(r['desc'] or '')[:60]}")
